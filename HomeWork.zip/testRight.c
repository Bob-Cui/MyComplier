




int a=1;
int b[1][3];


void test()
{
	return;	
}
int test1(int input)
{
	a=a+b;
	return 10;
}
int main(){
	for(int i=1;i<10;i++){
		a=(a*b+c)*(b+v);
	}
	if(a<b)
	{
		c=c+1;
	}
    else{
    	c=c+4;
	}	
	return 0;
}
