# ANTLR的使用





# 编译原理

```mermaid
graph TB
A[词法分析]-->B[语法分析]


```







