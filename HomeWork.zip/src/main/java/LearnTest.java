import GUI.MyErrorListener;
;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

public class LearnTest {


    public static void main(String[] args) {


//        for()




    }
}
